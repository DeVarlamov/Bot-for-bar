import telebot
from telebot import types  # для указание типов
import config

bot = telebot.TeleBot(config.token)
chat = (config.chat_id)


@bot.message_handler(commands=['start'])
def start(message):
    """Функция старта."""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("📒 Меню")
    btn2 = types.KeyboardButton("👽 Резерв стола")
    markup.add(btn1, btn2)
    with open('картинки/лого.jpg', 'rb') as photo:
        bot.send_photo(
            message.chat.id, photo,
            caption="Привет, {0.first_name}!"
            " Вас приветствуют бар мерзавчики.🐴🐴🐴".format(message.from_user),
            reply_markup=markup
        )


def beck(message):
    """Функция старта."""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("📒 Меню")
    btn2 = types.KeyboardButton("👽 Резерв стола")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, text="Ну и хрен с тобой, "
                     "{0.first_name}!".format(message.from_user),
                     reply_markup=markup)


@bot.message_handler(content_types=['text'])
def func(message):
    """Функция ответа пользоввателю."""
    if message.text == "👽 Резерв стола":
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("отмена⛔️")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Введите дату (дд.мм.):",
                         reply_markup=markup)
        bot.register_next_step_handler(message, get_date)
    elif (message.text == "📒 Меню"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Бар🥃")
        btn2 = types.KeyboardButton("Кухня🍕")
        back = types.KeyboardButton("🔙")
        markup.add(btn1, btn2, back)
        bot.send_message(message.chat.id, text="Смотри что у нас есть",
                         reply_markup=markup)

    elif (message.text == "🔙"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton("📒 Меню")
        button2 = types.KeyboardButton("👽 Резерв стола")
        markup.add(button1, button2)
        bot.send_message(message.chat.id, text="Вы вернулись в главное меню",
                         reply_markup=markup)
    elif (message.text == "Бар🥃"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("🔙")
        btn3 = types.KeyboardButton("Сами наливаем🛠")
        btn4 = types.KeyboardButton("Винная карта🍷")
        btn5 = types.KeyboardButton("Крепач🚀")
        btn6 = types.KeyboardButton("Без Алко🏇")
        markup.add(btn3, btn4, btn5, btn6, back)
        bot.send_message(message.chat.id, text="Ну, {0.first_name}!"
                         " Чем нахуяримся?".format(message.from_user),
                         reply_markup=markup)
    elif (message.text == "Кухня🍕"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("📒 Меню")
        back = types.KeyboardButton("🔙")
        btn2 = types.KeyboardButton("Бар🥃")
        markup.add(btn1, btn2, back)
        with open('картинки/кухня.jpg', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name} это еда ее едят!"
                .format(message.from_user),
                reply_markup=markup
            )
    elif (message.text == "Сами наливаем🛠"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("🔙")
        btn4 = types.KeyboardButton("Винная карта🍷")
        btn5 = types.KeyboardButton("Крепач🚀")
        btn6 = types.KeyboardButton("Без Алко🏇")
        markup.add(btn5, btn4, btn6, back)
        with open('картинки/бар.jpg', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name}, а ты шутить не любишь!"
                .format(message.from_user),
                reply_markup=markup
            )

    elif (message.text == "Винная карта🍷"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("🔙")
        btn3 = types.KeyboardButton("Сами наливаем🛠")
        btn5 = types.KeyboardButton("Крепач🚀")
        btn6 = types.KeyboardButton("Без Алко🏇")
        markup.add(btn3, btn5, btn6, back)
        with open('картинки/Вино.jpg', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name}, вот наша винность"
                .format(message.from_user),
                reply_markup=markup
            )

    elif (message.text == "Игорь гей"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("📒 Меню")
        back = types.KeyboardButton("🔙")
        markup.add(btn1, back)
        with open('картинки/Игорь.jpg', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name},"
                " Ты хотел сказать его величество Гейство?!"
                .format(message.from_user),
                reply_markup=markup
            )

    elif (message.text == "Крепач🚀"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("🔙")
        btn3 = types.KeyboardButton("Сами наливаем🛠")
        btn4 = types.KeyboardButton("Винная карта🍷")
        btn6 = types.KeyboardButton("Без Алко🏇")
        markup.add(btn3, btn4, btn6, back)
        with open('картинки/крепкий.bmp', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name}, ну поехали"
                .format(message.from_user),
                reply_markup=markup
            )

    elif (message.text == "Без Алко🏇"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("🔙")
        btn3 = types.KeyboardButton("Сами наливаем🛠")
        btn4 = types.KeyboardButton("Винная карта🍷")
        btn5 = types.KeyboardButton("Крепач🚀")
        markup.add(btn3, btn4, btn5, back)
        with open('картинки/БА.jpg', 'rb') as photo:
            bot.send_photo(
                message.chat.id, photo,
                caption="{0.first_name}, Выходной, так выходной!"
                .format(message.from_user),
                reply_markup=markup
            )

    else:
        bot.send_message(message.chat.id,
                         text="На такую комманду я не запрограммировал..")


def get_date(message):
    """Получение даты."""
    date = message.text
    if "отмена⛔️" in date.lower():
        bot.send_message(message.chat.id, text="Бронирование отменено",)
        beck(message)
    else:
        bot.send_message(message.chat.id, "Введите время (чч:мм):")
        bot.register_next_step_handler(message, get_time, date)


def get_time(message, date):
    """Получение времени ."""
    time = message.text
    if "отмена⛔️" in time.lower():
        bot.send_message(message.chat.id, text="Бронирование отменено",)
        beck(message)
    else:
        bot.send_message(message.chat.id, "Введите количество гостей:")
        bot.register_next_step_handler(message, get_guests, date, time)


def get_guests(message, date, time):
    """Получение контактных данных ."""
    guests = message.text
    if "отмена⛔️" in guests.lower():
        bot.send_message(message.chat.id, text="Бронирование отменено",)
        beck(message)
    else:
        bot.send_message(message.chat.id, "Введите ваши контактные данные:")
        bot.register_next_step_handler(
            message, get_contact_info,
            date, time, guests
            )


def get_contact_info(message, date, time, guests):
    """Получение сообщения."""
    contact_info = message.text
    # Check if the message text contains keywords to cancel the reservation
    if "отмена⛔️" in contact_info.lower():
        bot.send_message(message.chat.id, text="Бронирование отменено",)
        beck(message)
    else:
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("Вернуться в главное меню🔙")
        markup.add(back)
        bot.send_message(message.chat.id, text="Спасибо за резерв!"
                         " Мы ждем {}х гостей, {} в {} ."
                         "\nВаши контакты {}".format(
                            guests, date, time,  contact_info
                            ), reply_markup=markup)
        bot.send_message(
            chat_id=chat,
            text="Внимание бронь на {} "
            "в {} для {} гостей. Контактная"
            "информация: {}.".format(date, time, guests, contact_info))


bot.polling(none_stop=True)
